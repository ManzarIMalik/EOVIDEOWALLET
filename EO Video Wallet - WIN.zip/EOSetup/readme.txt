Prerequisites:
1) .net framework 4.7.2 or higher
2) Webview 2 runtime https://msedge.sf.dl.delivery.mp.microsoft.com/filestreamingservice/files/2be50253-2735-4f38-9193-08d2bdd034d5/MicrosoftEdgeWebview2Setup.exe
3) For windows 7 users. service pack 1 must be installed